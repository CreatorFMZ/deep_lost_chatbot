# deep_lost_x2-1.4.0.py
import tkinter as tk
from tkinter import scrolledtext, messagebox, filedialog
import random
import time
import datetime
import pyperclip  # 需要 pip install pyperclip

VERSION = "1.4.0"

LENGTH_RANGES = {
    "短": (100, 500),
    "中": (500, 1000),
    "长": (1000, 2000)
}

common_chars = [
    "的", "一", "是", "在", "不", "了", "有", "和", "人", "这", "中", "大", "为", "上", "个", "国", "我", "以", "要", "他",
    "时", "来", "用", "们", "生", "到", "作", "地", "于", "出", "就", "分", "对", "成", "会", "可", "主", "发", "年", "动",
    "同", "工", "也", "能", "下", "过", "子", "说", "产", "种", "面", "而", "方", "后", "多", "定", "行", "学", "法", "所",
    "民", "得", "经", "十", "三", "之", "进", "着", "等", "部", "度", "家", "电", "力", "里", "如", "水", "化", "高", "自",
    "二", "理", "起", "小", "物", "现", "实", "加", "量", "都", "两", "体", "制", "机", "当", "使", "点", "从", "业", "本",
    "去", "把", "性", "好", "应", "开", "它", "合", "还", "因", "由", "其", "些", "然", "前", "外", "天", "政", "四", "日",
    "那", "社", "义", "事", "平", "形", "相", "全", "表", "间", "样", "与", "关", "各", "重", "新", "线", "内", "数", "正",
    "心", "反", "你", "明", "看", "原", "又", "么", "利", "比", "或", "但", "质", "气", "第", "向", "道", "命", "此", "变",
    "条", "只", "没", "结", "解", "问", "意", "建", "月", "公", "无", "系", "军", "很", "情", "者", "最", "立", "代", "想",
    "已", "通", "并", "提", "直", "题", "党", "程", "展", "五", "果", "料", "象", "员", "次", "位", "常", "文", "总", "次",
    "品", "式", "活", "设", "及", "管", "特", "件", "长", "求", "老", "头", "基", "资", "边", "流", "路", "级", "少", "图",
    "山", "统", "接", "知", "较", "将", "组", "见", "计", "别", "她", "手", "角", "期", "根", "论", "运", "农", "指", "几",
    "九", "区", "强", "放", "决", "西", "被", "干", "做", "必", "战", "先", "回", "则", "任", "取", "据", "处", "队", "南",
    "给", "色", "光", "门", "即", "保", "治", "北", "造", "百", "规", "热", "领", "七", "海", "口", "东", "导", "器", "压",
    "志", "世", "金", "增", "争", "济", "阶", "油", "思", "术", "极", "交", "受", "联", "什", "认", "六", "共", "权", "收",
    "证", "改", "清", "美", "再", "采", "转", "更", "单", "风", "切", "打", "白", "教", "速", "花", "带", "安", "场", "身",
    "车", "例", "真", "务", "具", "万", "每", "目", "至", "达", "走", "积", "示", "议", "声", "报", "斗", "完", "类", "八",
    "离", "华", "名", "确", "才", "科", "张", "信", "马", "节", "话", "米", "整", "空", "元", "况", "今", "集", "温", "传",
    "土", "许", "步", "群", "广", "石", "记", "需", "段", "研", "界", "拉", "林", "律", "叫", "且", "究", "观", "越", "织",
    "装", "影", "算", "低", "持", "音", "众", "书", "布", "复", "容", "儿", "须", "际", "商", "非", "验", "连", "断", "深",
    "难", "近", "矿", "千", "周", "委", "素", "技", "备", "半", "办", "青", "省", "列", "习", "响", "约", "支", "般", "史",
    "感", "劳", "便", "团", "往", "酸", "历", "市", "克", "何", "除", "消", "构", "府", "称", "太", "准", "精", "值", "号",
    "率", "族", "维", "划", "选", "标", "写", "存", "候", "毛", "亲", "快", "效", "斯", "院", "查", "江", "型", "眼", "王"
]

class DeepLostX2:
    def __init__(self, root):
        self.root = root
        root.title(f"DeepLost X2 - 先进语言模型 v{VERSION}")
        root.geometry("920x720")
        root.minsize(820, 620)
        root.configure(bg="#f0f2f5")

        self.font = ("Microsoft YaHei", 12)
        self.title_font = ("Microsoft YaHei", 15, "bold")

        # 主输出区
        self.output = scrolledtext.ScrolledText(
            root, wrap=tk.WORD, font=self.font,
            bg="#ffffff", fg="#1a1a1a",
            insertbackground="#0066cc"
        )
        self.output.pack(padx=12, pady=(12, 6), fill=tk.BOTH, expand=True)

        # 状态栏
        self.status = tk.Label(
            root, text="启动中...", font=self.font,
            fg="#0066cc", bg="#f0f2f5", anchor="w"
        )
        self.status.pack(fill=tk.X, padx=12, pady=(0, 4))

        # 输入 + 模型选择区域
        input_frame = tk.Frame(root, bg="#f0f2f5")
        input_frame.pack(fill=tk.X, padx=12, pady=6)

        self.input_entry = tk.Entry(
            input_frame, font=self.font, relief="flat",
            bg="#ffffff", insertbackground="#0066cc"
        )
        self.input_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8), ipady=5)
        self.input_entry.bind("<Return>", self.on_send)

        self.model_var = tk.StringVar(value="thinking")
        model_menu = tk.OptionMenu(input_frame, self.model_var, "thinking", "fast")
        model_menu.config(font=self.font, width=8, relief="flat")
        model_menu.pack(side=tk.LEFT, padx=(0, 8))
        self.model_var.trace_add('write', self.on_model_change)

        send_btn = tk.Button(
            input_frame, text="发送", font=self.font,
            bg="#0066cc", fg="white", relief="flat",
            activebackground="#0055aa", command=self.on_send
        )
        send_btn.pack(side=tk.LEFT, ipadx=12, ipady=4)

        # 底部控制栏
        bottom_frame = tk.Frame(root, bg="#f0f2f5")
        bottom_frame.pack(fill=tk.X, padx=12, pady=8)

        # 左側：关于 / 长度选择
        left_frame = tk.Frame(bottom_frame, bg="#f0f2f5")
        left_frame.pack(side=tk.LEFT)

        about_btn = tk.Button(
            left_frame, text="关于", font=self.font,
            bg="#6c757d", fg="white", relief="flat",
            command=self.on_about
        )
        about_btn.pack(side=tk.LEFT, padx=(0, 8), ipadx=10, ipady=3)

        length_label = tk.Label(left_frame, text="长度:", font=self.font, bg="#f0f2f5")
        length_label.pack(side=tk.LEFT, padx=(12, 4))

        self.length_var = tk.StringVar(value="中")
        self.length_menu = tk.OptionMenu(left_frame, self.length_var, "短", "中", "长")
        self.length_menu.config(font=self.font, width=6, relief="flat")
        self.length_menu.pack(side=tk.LEFT)

        # 右側：功能按钮
        right_frame = tk.Frame(bottom_frame, bg="#f0f2f5")
        right_frame.pack(side=tk.RIGHT)

        copy_btn = tk.Button(
            right_frame, text="复制", font=self.font,
            bg="#6c757d", fg="white", relief="flat",
            command=self.copy_output
        )
        copy_btn.pack(side=tk.LEFT, padx=(0, 6), ipadx=10, ipady=3)

        save_btn = tk.Button(
            right_frame, text="保存文本", font=self.font,
            bg="#6c757d", fg="white", relief="flat",
            command=self.save_output
        )
        save_btn.pack(side=tk.LEFT, padx=(0, 6), ipadx=10, ipady=3)

        self.end_btn = tk.Button(
            right_frame, text="结束对话", font=self.font,
            bg="#dc3545", fg="white", relief="flat",
            command=self.on_end_conversation
        )
        self.end_btn.pack(side=tk.LEFT, ipadx=10, ipady=3)

        # 初始狀態
        self.first_response = True
        self.ended = False
        self.startup_step = 0
        self.startup_messages = [
            ("初始化智能系统...", 250),
            ("加载语言模型..........", 300),
            ("连接语义网络..........", 200),
            ("系统就绪！", 0)
        ]

        self.root.after(50, self.next_startup)

    def next_startup(self):
        if self.startup_step >= len(self.startup_messages):
            return
        msg, delay = self.startup_messages[self.startup_step]
        self.status.config(text=msg)
        self.startup_step += 1
        if self.startup_step < len(self.startup_messages):
            self.root.after(delay, self.next_startup)
        else:
            self.root.after(200, self.show_greeting)

    def show_greeting(self):
        self.append_output("【AI助手】您好！我是DeepLost-X2，一个先进的语言模型。\n")
        self.append_output("【AI助手】我可以帮助您创作诗歌、文章、故事或任何文本内容。\n")
        self.append_output("【AI助手】请在下方输入您的请求或主题：\n\n")
        self.status.config(text="就绪")

    def append_output(self, text):
        self.output.insert(tk.END, text)
        self.output.see(tk.END)
        self.root.update_idletasks()

    def on_send(self, event=None):
        if self.ended:
            return
        query = self.input_entry.get().strip()
        if not query:
            return
        self.append_output(f"\n【用户】: {query}\n")
        self.input_entry.delete(0, tk.END)
        self.status.config(text="正在分析您的请求...")
        self.root.after(300, lambda: self.simulate_processing(query))

    def simulate_processing(self, query):
        mode = self.model_var.get()
        self.processing_base = f"【系统】正在分析您的请求: \"{query}\"（模式: {mode}） 深度神经网络处理中"
        self.status.config(text=self.processing_base)
        self.dot_count = 0

        if mode == 'fast':
            self.dot_limit = 5
            self.dot_interval = 100
            self.final_delay = 200
        else:
            self.dot_limit = 10
            self.dot_interval = 280
            self.final_delay = 600

        self.add_dots()

    def add_dots(self):
        if self.dot_count < self.dot_limit:
            self.status.config(text=self.status.cget("text") + ".")
            self.dot_count += 1
            self.root.after(self.dot_interval, self.add_dots)
        else:
            self.root.after(self.final_delay, self.generate_response)

    def generate_text(self):
        mode = self.model_var.get()

        if mode == 'fast':
            length = random.randint(10, 150)
            return ''.join(random.choices(common_chars, k=length))

        # thinking 模式
        choice = self.length_var.get()
        low, high = LENGTH_RANGES.get(choice, (150, 800))
        length = random.randint(low, high)
        text = ''.join(random.choices(common_chars, k=length))

        punct = ['，', '。', '！', '？', '；', '：', '、']
        positions = sorted(random.sample(range(5, length - 5), min(length // 12, 40)))
        offset = 0
        for pos in positions:
            p = random.choice(punct)
            text = text[:pos + offset] + p + text[pos + offset:]
            offset += 1

        para_positions = sorted(random.sample(range(50, len(text) - 50), max(1, len(text) // 120)))
        offset = 0
        for pos in para_positions:
            text = text[:pos + offset] + "\n\n" + text[pos + offset:]
            offset += 2

        return text

    def generate_response(self):
        text = self.generate_text()

        prefix = "基于您的主题，我创作了以下内容：" if self.first_response else "根据您的反馈，我优化了内容："
        self.first_response = False

        self.append_output(f"【AI助手】{prefix}\n")
        self.append_output("════════════════════════════════════════\n")
        self.append_output(text + "\n")
        self.append_output("════════════════════════════════════════\n\n")
        self.append_output("【AI助手】您对结果满意吗？请输入反馈或新请求（点击“结束对话”结束会话）。\n")
        self.status.config(text="就绪")

    def copy_output(self):
        try:
            pyperclip.copy(self.output.get("1.0", tk.END).strip())
            self.status.config(text="已复制到剪贴板")
            self.root.after(1800, lambda: self.status.config(text="就绪") if not self.ended else None)
        except Exception:
            self.status.config(text="复制失败")
            self.root.after(1800, lambda: self.status.config(text="就绪") if not self.ended else None)

    def save_output(self):
        content = self.output.get("1.0", tk.END).strip()
        if not content:
            return

        now = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        default_name = f"DeepLost-X2_{now}.txt"

        filepath = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("文本文件", "*.txt"), ("所有文件", "*.*")],
            initialfile=default_name,
            title="保存输出为文本"
        )
        if not filepath:
            return

        try:
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(content)
            self.status.config(text="已保存为文本")
            self.root.after(1800, lambda: self.status.config(text="就绪") if not self.ended else None)
        except Exception as e:
            messagebox.showerror("保存失败", f"无法保存文件：\n{str(e)}")

    def on_about(self):
        info = f"DeepLost X2\n版本: {VERSION}\n© Fanatic Star 2026\n保留所有权利。"
        messagebox.showinfo("关于 DeepLost X2", info)

    def on_model_change(self, *args):
        mode = self.model_var.get()
        state = "disabled" if mode == "fast" else "normal"
        self.length_menu.config(state=state)
        if mode == "fast":
            self.length_var.set("短")

    def on_end_conversation(self):
        self.append_output("\n【系统】本次会话已结束。感谢使用DeepLost-X2！期待下次为您服务。©Fanatic Star 2026.\n")
        self.status.config(text="会话已结束")
        self.ended = True

        self.input_entry.config(state=tk.DISABLED)
        self.end_btn.config(state=tk.DISABLED)

        # 禁用大部分控件
        for widget in [self.send_btn, self.length_menu, self.model_menu]:
            try:
                widget.config(state=tk.DISABLED)
            except:
                pass

if __name__ == "__main__":
    root = tk.Tk()
    app = DeepLostX2(root)
    root.mainloop()